export default function Dashboard() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-3xl font-semibold mb-4">Dashboard</h1>
      <p className="text-gray-700">This is where your stats or messages will go.</p>
    </main>
  );
}
